<?php
$con = mysqli_connect('localhost','root', 'N0virus1!');
mysqli_select_db($con,'quizdb');
?>